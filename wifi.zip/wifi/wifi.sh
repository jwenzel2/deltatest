#!/bin/bash

##installing gcc
sudo apt install ./gcc-10_10.3.0-1ubuntu1_amd64.deb ./libcc1-0_11-20210417-1ubuntu1_amd64.deb ./binutils_2.36.1-6ubuntu1_amd64.deb ./binutils-common_2.36.1-6ubuntu1_amd64.deb ./libbinutils_2.36.1-6ubuntu1_amd64.deb ./binutils-x86-64-linux-gnu_2.36.1-6ubuntu1_amd64.deb ./libctf-nobfd0_2.36.1-6ubuntu1_amd64.deb ./libctf0_2.36.1-6ubuntu1_amd64.deb ./libgcc-10-dev_10.3.0-1ubuntu1_amd64.deb ./libitm1_11-20210417-1ubuntu1_amd64.deb ./libatomic1_11-20210417-1ubuntu1_amd64.deb ./libasan6_11-20210417-1ubuntu1_amd64.deb ./liblsan0_11-20210417-1ubuntu1_amd64.deb ./libtsan0_11-20210417-1ubuntu1_amd64.deb ./libubsan1_11-20210417-1ubuntu1_amd64.deb ./libquadmath0_11-20210417-1ubuntu1_amd64.deb 

##installing make
sudo apt install ./make_4.3-4ubuntu1_amd64.deb 

##install build-essential
sudo apt install ./build-essential_12.8ubuntu3_amd64.deb ./libc6-dev_2.33-0ubuntu5_amd64.deb ./gcc_10.3.0-1ubuntu1_amd64.deb ./g++-10_10.3.0-1ubuntu1_amd64.deb ./g++_10.3.0-1ubuntu1_amd64.deb ./dpkg-dev_1.20.9ubuntu1_all.deb ./lto-disabled-list_7_all.deb ./libstdc++-10-dev_10.3.0-1ubuntu1_amd64.deb ./libc-dev-bin_2.33-0ubuntu5_amd64.deb ./linux-libc-dev_5.11.0-16.17_amd64.deb ./libc6-dev_2.33-0ubuntu5_amd64.deb ./libcrypt-dev_4.4.17-1ubuntu3_amd64.deb ./rpcsvc-proto_1.4.2-0ubuntu4_amd64.deb ./libtirpc-dev_1.3.1-1build1_amd64.deb ./libnsl-dev_1.3.0-0ubuntu3_amd64.deb 

##unzip driver
unzip rtl8821CU-master.zip
cd rtl8821CU-master

##compile and install driver
sudo make
sudo make install

##load the driver
sudo modprobe 8821cu
